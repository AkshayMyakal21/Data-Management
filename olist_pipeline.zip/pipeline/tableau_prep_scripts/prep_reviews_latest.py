"""
Tableau Prep Script step  ->  reproduces CL_reviews (flags + review_rank).

In Tableau Prep:  IN_order_reviews  ->  [+] Script
    File name     : prep_reviews_latest.py
    Function name : reviews_ranked
Then keep the existing Filter  [review_rank] = 1  for fact_orders.
"""
import os
import sys

import pandas as pd

PIPELINE_DIR = os.environ.get("OLIST_PIPELINE_DIR",
                              r"C:\python\srh python\DM\DM_project\pipeline")
sys.path.insert(0, PIPELINE_DIR)
import olist_functions as F  # noqa: E402


def reviews_ranked(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for c in F.DATE_COLUMNS["order_reviews"]:
        df[c] = pd.to_datetime(df[c], errors="coerce")
    return F.clean_reviews(df)


def get_output_schema():
    return pd.DataFrame({
        "review_id": prep_string(),
        "order_id": prep_string(),
        "review_score": prep_int(),
        "review_comment_title": prep_string(),
        "review_comment_message": prep_string(),
        "review_creation_date": prep_datetime(),
        "review_answer_timestamp": prep_datetime(),
        "review_key": prep_string(),
        "has_comment": prep_int(),
        "is_low_score": prep_int(),
        "review_rank": prep_int(),
    })
