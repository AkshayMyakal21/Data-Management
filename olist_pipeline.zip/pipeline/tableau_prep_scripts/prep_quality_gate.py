"""
Tableau Prep Script step  ->  quality gate on fact_orders, inside the flow.

In Tableau Prep:  CL_fact_orders  ->  [+] Script  ->  Output "quality_gate_report.csv"
    File name     : prep_quality_gate.py
    Function name : gate_fact_orders

The step returns the check report (one row per check). If any check is FAIL
the step raises an error, so the Prep run stops and fact_orders is NOT published.
"""
import os
import sys

import pandas as pd

PIPELINE_DIR = os.environ.get("OLIST_PIPELINE_DIR",
                              r"C:\python\srh python\DM\DM_project\pipeline")
sys.path.insert(0, PIPELINE_DIR)
from quality_gate import run_quality_gate, assert_gate  # noqa: E402


def gate_fact_orders(df: pd.DataFrame) -> pd.DataFrame:
    report = run_quality_gate({"fact_orders": df})
    assert_gate(report)                  # stops the flow on FAIL
    return report


def get_output_schema():
    return pd.DataFrame({
        "table": prep_string(),
        "check": prep_string(),
        "failed_rows": prep_int(),
        "status": prep_string(),
        "detail": prep_string(),
    })
