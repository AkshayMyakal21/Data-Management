"""
Tableau Prep Script step  ->  replaces / reproduces the CL_orders clean step.

In Tableau Prep:  IN_orders  ->  [+] Script
    Connection type : Tableau Python (TabPy) Server   (localhost : 9004)
    File name       : prep_orders_kpis.py
    Function name   : orders_kpis

The logic is NOT copied here - it is imported from olist_functions.py,
so Python and Tableau Prep always run the same code.
"""
import os
import sys

import pandas as pd

PIPELINE_DIR = os.environ.get("OLIST_PIPELINE_DIR",
                              r"C:\python\srh python\DM\DM_project\pipeline")
sys.path.insert(0, PIPELINE_DIR)
import olist_functions as F  # noqa: E402

NULLABLE_INT = ["delivery_days", "delay_days", "seller_handling_days", "is_late"]


def orders_kpis(df: pd.DataFrame) -> pd.DataFrame:
    date_cols = F.DATE_COLUMNS["orders"]
    df = df.copy()
    df[date_cols] = df[date_cols].apply(pd.to_datetime, errors="coerce")
    out = F.clean_orders(df)
    out[NULLABLE_INT] = out[NULLABLE_INT].astype("float")   # TabPy cannot send pd.NA
    return out


def get_output_schema():
    # prep_* helpers are provided by Tableau Prep at run time
    return pd.DataFrame({
        "order_id": prep_string(),
        "customer_id": prep_string(),
        "order_status": prep_string(),
        "order_purchase_timestamp": prep_datetime(),
        "order_approved_at": prep_datetime(),
        "order_delivered_carrier_date": prep_datetime(),
        "order_delivered_customer_date": prep_datetime(),
        "order_estimated_delivery_date": prep_datetime(),
        "purchase_date": prep_datetime(),
        "purchase_month": prep_datetime(),
        "delivery_days": prep_decimal(),
        "delay_days": prep_decimal(),
        "seller_handling_days": prep_decimal(),
        "is_late": prep_decimal(),
        "dq_flag": prep_string(),
    })
